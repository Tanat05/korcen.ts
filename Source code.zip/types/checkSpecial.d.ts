export declare function special(text: string | any): boolean;
