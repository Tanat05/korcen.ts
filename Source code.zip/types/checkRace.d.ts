export declare function race(text: string | any): boolean;
