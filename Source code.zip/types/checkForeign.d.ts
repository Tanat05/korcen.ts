export declare function foreign(text: string | any): boolean;
