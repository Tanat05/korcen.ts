export declare function parents(text: string | any): boolean;
