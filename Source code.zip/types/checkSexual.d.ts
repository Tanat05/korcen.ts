export declare function sexual(text: string | any): boolean;
