export declare function minor(text: string | any): boolean;
