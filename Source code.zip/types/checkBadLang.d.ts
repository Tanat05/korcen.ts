export declare function check(text: string | any): boolean;
