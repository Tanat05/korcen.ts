export declare function belittle(text: string | any): boolean;
