export declare function general(text: string | any): boolean;
