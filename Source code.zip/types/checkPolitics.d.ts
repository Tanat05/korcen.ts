export declare function politics(text: string | any): boolean;
